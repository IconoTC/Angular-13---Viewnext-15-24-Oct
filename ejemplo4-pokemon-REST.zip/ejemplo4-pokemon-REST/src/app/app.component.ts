import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any[] = [];
  urlSiguientes: string = '';
  urlAnteriores: string = '';
  atrasDeshabilitado: boolean = true;
  nombre: string = '';
  pokemon: any;

  constructor(private pokemonService: PokemonService){

    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    pokemonService.getAll().subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguientes = datos.next;
    });
  }

  buscar(): void{
    this.pokemonService.buscarPokemon(this.nombre).subscribe(
      item => {
        console.log(item);
        this.pokemon = item;
      },
      error => {
        console.log(error);
        alert("Pokemon no encontrado");
        this.nombre = '';
      }
    );
  }

  siguientes(): void{
    this.pokemonService.emitirPeticion(this.urlSiguientes).subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguientes = datos.next;
      this.urlAnteriores = datos.previous;
      this.atrasDeshabilitado = false;
    });
  }

  anteriores(): void{
    this.pokemonService.emitirPeticion(this.urlAnteriores).subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.urlSiguientes = datos.next;
      this.urlAnteriores = datos.previous;
      if (this.urlAnteriores == null){
        this.atrasDeshabilitado = true;
      }
    });
  }
}

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyD_tXajjvPaLSgMFpuX_VkCaJ5p_S2TbR8",
    authDomain: "angular-anabel-20-septiembre.firebaseapp.com",
    projectId: "angular-anabel-20-septiembre",
    storageBucket: "angular-anabel-20-septiembre.appspot.com",
    messagingSenderId: "354470774219",
    appId: "1:354470774219:web:7689651a256b7d1471a24e"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numClicks: number = 0;

  @HostBinding('style.font-size')  // Funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  constructor() { }

  @HostListener('click')
  procesarClicks(): void{
    //alert('Has hecho click');
    this.numClicks++;
    this.size = 15 + this.numClicks + "px";
    this.opacidad += 0.1;
  }

}

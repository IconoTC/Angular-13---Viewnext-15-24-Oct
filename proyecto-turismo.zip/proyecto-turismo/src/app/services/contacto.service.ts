import { AngularFirestore, DocumentReference } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  private db = "/contactos";

  constructor(private angularFirestore: AngularFirestore) { }

  enviarDatos(datos: any): Promise<DocumentReference<unknown>>{
    return this.angularFirestore.collection(this.db).add(datos);
  }
}

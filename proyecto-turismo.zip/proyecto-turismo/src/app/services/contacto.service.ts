import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  constructor() { }

  enviarDatos(datos: any): void{
    console.log(datos);
  }
}

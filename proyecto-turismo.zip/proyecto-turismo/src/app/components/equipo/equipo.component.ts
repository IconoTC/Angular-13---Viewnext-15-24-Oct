import { Component, OnInit } from '@angular/core';
import { EquipoService } from 'src/app/services/equipo.service';

@Component({
  selector: 'app-equipo',
  templateUrl: './equipo.component.html',
  styleUrls: ['./equipo.component.css']
})
export class EquipoComponent implements OnInit {

  equipo: any[] = [];

  constructor(private equipoService: EquipoService) { 

    equipoService.getAll().subscribe( datos => {
      console.log(datos);
      this.equipo = datos.results;
    });
  }

  ngOnInit(): void {
  }

}

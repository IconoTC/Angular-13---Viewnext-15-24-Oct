import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-detalle-museo',
  templateUrl: './detalle-museo.component.html',
  styleUrls: ['./detalle-museo.component.css']
})
export class DetalleMuseoComponent implements OnInit {

  id: number = 0;
  museo?: Museo;

  constructor(private ruta: ActivatedRoute, private museosService: MuseosService) { 
    // recuperar el id
    this.id = ruta.snapshot.params['codigo'];
    //alert(this.id);

    // Buscar el museo con ese id
    this.museo = museosService.buscarMuseo(this.id);
  }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ContactoService } from 'src/app/services/contacto.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contactoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7,9]{1}[0-9]{8}')]),
    email: new FormControl('', [Validators.required, Validators.email]),
    asunto: new FormControl('', [Validators.required, Validators.minLength(5)]),
    mensaje: new FormControl('', [Validators.required, Validators.minLength(10)]),
  });

  constructor(private contactoService: ContactoService) { }

  guardar(): void{
    this.contactoService.enviarDatos(this.contactoForm.value)
      .then(() => {
        alert("Contacto guardado");
        this.contactoForm.reset();
      })
      .catch(error  => {
        console.log(error);
      })
  }

  ngOnInit(): void {
  }

}
